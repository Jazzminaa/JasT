"use strict";
var Category = (function () {
    function Category() {
    }
    return Category;
}());
exports.Category = Category;
//# sourceMappingURL=category.model.js.map