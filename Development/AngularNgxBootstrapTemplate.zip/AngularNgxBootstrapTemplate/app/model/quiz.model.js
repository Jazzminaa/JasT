"use strict";
var Quiz = (function () {
    function Quiz() {
    }
    return Quiz;
}());
exports.Quiz = Quiz;
//# sourceMappingURL=quiz.model.js.map