export class User{
    id: number;
    dateOfBirth: Date;
    email: string;
    firstName: string;
    lastName: string;
    username: string;
    gender: string;
    password: string;
}