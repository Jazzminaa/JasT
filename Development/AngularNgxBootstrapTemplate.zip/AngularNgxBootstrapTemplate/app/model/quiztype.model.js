"use strict";
var QuizType = (function () {
    function QuizType() {
    }
    return QuizType;
}());
exports.QuizType = QuizType;
//# sourceMappingURL=quiztype.model.js.map