import { Component } from '@angular/core'

@Component(
    {
        selector: 'home',
        template: `
          <h4>Herzlich Willkommen</h4>   
        `      
    }
)
export class HomeComponent {

}