package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

public interface DataAccessObject<T> {
	T findById(int id);
	List<T> findAll();
	void add(T t);
	void delete(int id);
	void edit(T t);
}
