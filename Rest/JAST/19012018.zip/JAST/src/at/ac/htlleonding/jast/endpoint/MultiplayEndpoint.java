package at.ac.htlleonding.jast.endpoint;


import java.util.LinkedList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.Status;

import at.ac.htlleonding.jast.dataaccess.*;
import at.ac.htlleonding.jast.datatransport.*;
import at.ac.htlleonding.jast.model.*;

@RequestScoped
@Path("/multiplays")
@Produces("application/json")
@Consumes("application/json")
public class MultiplayEndpoint {
	
	@Inject
	MultiplayDao multiplayDao;
	
	@Inject
	QuizDao quizDao;
	
	@Inject
	UserDao userDao;
	

	@POST
	public Response create(final MultiplayDto contentdto) {
		Multiplay con = new Multiplay();
		multiplayDao.add(getMultiplayfromMultiplayDto(contentdto, con));	
		return Response.created(UriBuilder.fromResource(ContentEndpoint.class).path(String.valueOf(con.getId())).build()).build();
	}



	@GET
	@Path("/{id:[0-9][0-9]*}")
	public Response findById(@PathParam("id") final Long id) {
		Multiplay multiplay = multiplayDao.findById(id.intValue());
		if (multiplay == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(getMultiplayDtofromMultiplay(multiplay)).build();
	}
	
	@GET
	@Path("/quiz/{id:[0-9][0-9]*}")
	public List<MultiplayDto> findByListType(@PathParam("id") final Long id) {
		final List<Multiplay> multiplay = multiplayDao.findByQuiz(id.intValue());
		List<MultiplayDto> multiplaydtoes = new LinkedList<MultiplayDto>();
		
		for(Multiplay m : multiplay) {
			multiplaydtoes.add(getMultiplayDtofromMultiplay(m));
		}
		return multiplaydtoes;
	}
	
	@GET
	public List<Multiplay> listAll(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		final List<Multiplay> users = multiplayDao.findAll();
		List<Multiplay> contentdtoes = new LinkedList<Multiplay>();
		
		for(Multiplay u : users) {
			contentdtoes.add(u);
		}
		return contentdtoes;
	}

	@PUT
	@Path("/{id:[0-9][0-9]*}")
	public Response update(@PathParam("id") Long id, final Quiz userdto) {
		Multiplay u = multiplayDao.findById(id.intValue());
		//userDao.edit(getUserFromDto(userdto, u, false, userDao, householdDao, householduserDao, countryDao, userroleDao, pocketmoneycalculatorDao));
		return Response.noContent().build();
	}

	@DELETE
	@Path("/{id:[0-9][0-9]*}")
	public Response deleteById(@PathParam("id") final Long id) {
		multiplayDao.delete(id.intValue());
		return Response.noContent().build();
	}
	


	public MultiplayDto getMultiplayDtofromMultiplay(Multiplay multiplay) {
		MultiplayDto multiplayDto = new MultiplayDto();
		multiplayDto.setId(multiplay.getId());
		multiplayDto.setName(multiplay.getName());
		
		UserDto owner = new UserEndpoint().getUserDtofromUser(multiplay.getUser());
		multiplayDto.setOwnwer(owner);
		
		QuizDto quiz = new QuizEndpoint().getQuizDtofromQuiz(multiplay.getQuiz());
		multiplayDto.setQuiz(quiz);

		return multiplayDto;
	}


	public Multiplay getMultiplayfromMultiplayDto(MultiplayDto multiplayDto, Multiplay multiplay ) {
		
		multiplay.setId(multiplayDto.getId());
		multiplay.setName(multiplayDto.getName());
		User user = userDao.findById(multiplayDto.getOwnwer().getId());
		multiplay.setUser(user);
		
		
		Quiz quiz = quizDao.findById(multiplayDto.getQuiz().getId());
		multiplay.setQuiz(quiz);

		return multiplay;
	}
	


}
