package at.ac.htlleonding.jast.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the rightanswer database table.
 * 
 */
@Entity
@NamedQuery(name="Rightanswer.findAll", query="SELECT r FROM Rightanswer r")
public class Rightanswer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private Timestamp timestamp;

	//bi-directional many-to-one association to Content
	@ManyToOne
	private Content content;

	//bi-directional many-to-one association to Multiplay
	@ManyToOne
	@JoinColumn(name="Multiplayer_id")
	private Multiplay multiplay;

	//bi-directional many-to-one association to User
	@ManyToOne
	private User user;

	public Rightanswer() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Timestamp getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public Content getContent() {
		return this.content;
	}

	public void setContent(Content content) {
		this.content = content;
	}

	public Multiplay getMultiplay() {
		return this.multiplay;
	}

	public void setMultiplay(Multiplay multiplay) {
		this.multiplay = multiplay;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}