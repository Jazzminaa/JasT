package at.ac.htlleonding.jast.endpoint;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.persistence.Convert;
import javax.websocket.CloseReason;
import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.jboss.logging.Logger;

import at.ac.htlleonding.jast.dataaccess.QuizDao;

@ServerEndpoint(value = "/play/{room}")
public class WebsocketPlayEndpoint implements Serializable {
	
	private static final Logger LOG = Logger.getLogger(WebsocketPlayEndpoint.class.getName());
	private static final Map<String, List<Session>> sessions = Collections.synchronizedMap(new HashMap<String, List<Session>>());
	private static List<Session> peers = Collections.synchronizedList(new LinkedList<Session>());
	private static final Map<String, String> resultsUntilNow = Collections.synchronizedMap(new HashMap<String, String>());

    @OnMessage
    public String onMessage(String message , Session session, @PathParam("room") final String room) {
    	//debugen und schauen wieso es nicht an alle schickt
    	peers = sessions.get(room);
    	String results = resultsUntilNow.get(room).toString();
    	results += message +";";
    	resultsUntilNow.put(room, results);
    	int i=0;
    	while(peers.size()-1 >= i)
    	{
    		
    		Session se = peers.get(i);
    		try {
				se.getBasicRemote().sendText(room+ " -> " + resultsUntilNow.get(room).toString());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		i++;
    	}
    	
        return resultsUntilNow.get(room).toString();
    }
    @OnOpen
    public void onOpen(Session peer, @PathParam("room") final String room) {
        LOG.info("Connection opened ...");
        peer.getUserProperties().put("room", room);
        //peers.add(peer);
        if(sessions.containsKey(room))
        {
        	sessions.get(room).add(peer);
        	
        }
        else
        {
        	List<Session> newlist  = Collections.synchronizedList(new LinkedList<Session>());
        	newlist.add(peer);
        	resultsUntilNow.put(room, "");
        	sessions.put(room, newlist);
        }
        try {
        	peer.getBasicRemote().sendText("Anzah der Spieler: "+sessions.get(room).size());
			//peer.getBasicRemote().sendText(String.valueOf(peers.size()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @OnClose
    public void onClose(Session peer) {
        LOG.info("Connection closed ...");
        peers.remove(peer);
    }
	
	
}



