package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import at.ac.htlleonding.jast.model.*;

@Named
@Dependent
public class MultiplayDao implements DataAccessObject<Multiplay> {
	
	@PersistenceContext
	EntityManager em;

	public Multiplay findById(int id) {
		return em.find(Multiplay.class, id);
	}

	public List<Multiplay> findAll() {
		return em.createNamedQuery("Multiplay.findAll", Multiplay.class).getResultList();
	}

	@Transactional
	public void add(Multiplay t) {
		em.persist(t);
	}


	@Transactional
	public void delete(int id) {
		Multiplay c = em.find(Multiplay.class, id);
		em.remove(c);
	}

	@Transactional
	public void edit(Multiplay t) {
		Multiplay c = em.find(Multiplay.class, t.getId());
		c.setCounter(t.getCounter());
		em.merge(c);
	}
	


}
