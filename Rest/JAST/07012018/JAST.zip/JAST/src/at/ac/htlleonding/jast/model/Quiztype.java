package at.ac.htlleonding.jast.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the quiztype database table.
 * 
 */
@Entity
@NamedQuery(name="Quiztype.findAll", query="SELECT q FROM Quiztype q")
public class Quiztype implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String name;

	private Timestamp timestamp;

	/*//bi-directional many-to-one association to Quiz
	@OneToMany(mappedBy="quiztype")
	private List<Quiz> quizs;

	//bi-directional many-to-one association to Score
	@OneToMany(mappedBy="quiztype")
	private List<Score> scores;*/

	public Quiztype() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Timestamp getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	/*public List<Quiz> getQuizs() {
		return this.quizs;
	}

	public void setQuizs(List<Quiz> quizs) {
		this.quizs = quizs;
	}

	public Quiz addQuiz(Quiz quiz) {
		getQuizs().add(quiz);
		quiz.setQuiztype(this);

		return quiz;
	}

	public Quiz removeQuiz(Quiz quiz) {
		getQuizs().remove(quiz);
		quiz.setQuiztype(null);

		return quiz;
	}

	public List<Score> getScores() {
		return this.scores;
	}

	public void setScores(List<Score> scores) {
		this.scores = scores;
	}

	public Score addScore(Score score) {
		getScores().add(score);
		score.setQuiztype(this);

		return score;
	}

	public Score removeScore(Score score) {
		getScores().remove(score);
		score.setQuiztype(null);

		return score;
	}*/

}