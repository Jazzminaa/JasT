package at.ac.htlleonding.jast.endpoint;

import java.sql.Timestamp;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.Status;

import at.ac.htlleonding.jast.dataaccess.*;
import at.ac.htlleonding.jast.datatransport.*;
import at.ac.htlleonding.jast.model.*;

@RequestScoped
@Path("/users")
@Produces("application/json")
@Consumes("application/json")
public class UserEndpoint {
	
	@Inject
	UserDao userDao;
	

	@POST
	public Response create(final UserDto userdto) {
		
		User u = new User();
		userDao.add(getUserfromUserDto(userdto,userDao));	
		return Response.created(UriBuilder.fromResource(UserEndpoint.class).path(String.valueOf(u.getId())).build()).build();
	}


	@GET
	@Path("/{id:[0-9][0-9]*}")
	public Response findById(@PathParam("id") final Long id) {
		User u = userDao.findById(id.intValue());
		if (u == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(getUserDtofromUser(u)).build();
	}
	
	
	@GET
    @Path("/email/{email}")
    public Response findByEmail(@PathParam("email") final String email){
        User u = userDao.findByEmail(email);
        if (u == null) {
            return Response.status(Status.NOT_FOUND).build();
        }
        return Response.ok(getUserDtofromUser(u)).build();
    }
	
	@GET
    @Path("/{name}")
    public Response findByName(@PathParam("name") final String name){
        User u = userDao.findByName(name);
        if (u == null) {
            return Response.status(Status.NOT_FOUND).build();
        }
        return Response.ok(getUserDtofromUser(u)).build();
    }
	
	

	@GET
	public List<UserDto> listAll(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		final List<User> users = userDao.findAll();
		List<UserDto> userDtoes = new LinkedList<UserDto>();
		for (User user : users) {
			userDtoes.add(getUserDtofromUser(user));
		}
		return userDtoes;
	}


	@PUT
	@Path("/{id:[0-9][0-9]*}")
	public Response update(@PathParam("id") Long id, final UserDto userdto) {
		User u = userDao.findById(id.intValue());
		//userDao.edit(getUserFromDto(userdto, u, false, userDao, householdDao, householduserDao, countryDao, userroleDao, pocketmoneycalculatorDao));
		return Response.noContent().build();
	}

	@DELETE
	@Path("/{id:[0-9][0-9]*}")
	public Response deleteById(@PathParam("id") final Long id) {
		userDao.delete(id.intValue());
		return Response.noContent().build();
	}
	
	public UserDto getUserDtofromUser(User u)
	{
		UserDto userdto = new UserDto();
		userdto.setId(u.getId());
		userdto.setDateOfBirth(u.getDateOfBirth());
		userdto.setId(u.getId());
		userdto.setEmail(u.getEmail());
		userdto.setFirstname(u.getFirstname());
		userdto.setGender(u.getGender());
		userdto.setLastname(u.getLastname());
		userdto.setPassword(u.getPassword());
		userdto.setPicture(u.getPicture());
		userdto.setUsername(u.getUsername());
		
		MultiplayDto mp = new MultiplayEndpoint().getMultiplayDtofromMultiplay(u.getMultiplay());
		userdto.setMultiplay(mp); 
		return userdto;
	}


	public User getUserfromUserDto(UserDto u,UserDao userDao) {
		User user = new User();
		user = userDao.findById(u.getId());
		user.setId(u.getId());
		user.setDateOfBirth(u.getDateOfBirth());
		user.setId(u.getId());
		user.setEmail(u.getEmail());
		user.setFirstname(u.getFirstname());
		user.setGender(u.getGender());
		user.setLastname(u.getLastname());
		user.setPassword(u.getPassword());
		user.setPicture(u.getPicture());
		user.setUsername(u.getUsername());
		
		Multiplay mp = new MultiplayEndpoint().getMultiplayfromMultiplayDto(u.getMultiplay());
		user.setMultiplay(mp); 
		return user;
	}




}
