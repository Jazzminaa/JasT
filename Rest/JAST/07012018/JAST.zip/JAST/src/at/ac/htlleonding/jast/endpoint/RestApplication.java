package at.ac.htlleonding.jast.endpoint;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import at.ac.htlleonding.jast.filter.CORSFilter;

@ApplicationPath("/rest")
public class RestApplication extends Application {

	
	
}
