package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import at.ac.htlleonding.jast.model.*;

@Named
@Dependent
public class UserDao implements DataAccessObject<User>{
	
	@PersistenceContext
	EntityManager em;

	public User findById(int id) {
		return em.find(User.class, id);
	}

	public List<User> findAll() {
		List<User> u = em.createNamedQuery("User.findAll", User.class).getResultList();
		return u;
	}
	

	@Transactional
	public void add(User t) {
		em.persist(t);
	}


	@Transactional
	public void delete(int id) {
		User u = em.find(User.class, id);
		em.remove(u);
	}

	@Transactional
	public void edit(User t) {
		User u = em.find(User.class, t.getId());
		u.setUsername(t.getUsername());
		u.setEmail(t.getEmail());
		u.setPassword(t.getPassword());
		u.setFirstname(t.getFirstname());
		u.setLastname(t.getLastname());
		u.setDateOfBirth(t.getDateOfBirth());
		u.setGender(t.getGender());
		u.setPicture(t.getPicture());
		em.merge(u);
	}
	
	public User findByEmail(String email) {
        return (User) em.createQuery("select u from User u where u.email = :email").setParameter("email", email).getSingleResult();
    }

	public User findByName(String name) {
		return (User) em.createQuery("select u from User u where u.username = :name").setParameter("name", name).getSingleResult();
	}


	@Transactional
	public void save(User user) {
		int id = user.getId();
		User managedUser = em.find(User.class, id);
		managedUser.setUsername(user.getUsername());
		//TODO add more fields or give this to Student class
		em.merge(managedUser);
	}


}
