package at.ac.htlleonding.jast.endpoint;

import java.sql.Timestamp;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale.Category;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.Status;

import at.ac.htlleonding.jast.dataaccess.*;
import at.ac.htlleonding.jast.datatransport.*;
import at.ac.htlleonding.jast.model.*;

@RequestScoped
@Path("/quizes")
@Produces("application/json")
@Consumes("application/json")
public class QuizEndpoint {
	
	@Inject
	QuizDao quizDao;
	
	@Inject
	CategoryDao catDao;
	
	@Inject
	QuizTypeDao typeDao;
	
	@Inject
	UserDao userDao;
	

	@POST
	public Response create(final QuizDto quizdto) {
		
		Quiz q = new Quiz();
		quizDao.add(getQuizfromQuizDto(quizdto));	
		return Response.created(UriBuilder.fromResource(QuizEndpoint.class).path(String.valueOf(q.getId())).build()).build();
	}


	@GET
	@Path("/{id:[0-9][0-9]*}")
	public Response findById(@PathParam("id") final Long id) {
		Quiz q = quizDao.findById(id.intValue());
		if (q == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(getQuizDtofromQuiz(q)).build();
	}
	
	@GET
	@Path("/category/{id:[0-9][0-9]*}")
	public List<QuizDto> findByListType(@PathParam("id") final Long id) {
		final List<Quiz> quizes = quizDao.findByCategory(id.intValue());
		List<QuizDto> quizdtoes = new LinkedList<QuizDto>();
		
		for(Quiz q : quizes) {
			quizdtoes.add(getQuizDtofromQuiz(q));
		}
		return quizdtoes;
	}
	
	@GET
    @Path("/user/{id:[0-9][0-9]*}/name/{name}")
    public Response findByUserandName(@PathParam("id") final Long id,@PathParam("name") final String name){
        Quiz q = quizDao.findByUserAndName(id.intValue(), name);
        if (q == null) {
            return Response.status(Status.NOT_FOUND).build();
        }
        return Response.ok(getQuizDtofromQuiz(q)).build();
    }
	
	@GET
    @Path("/{name}")
    public Response findByName(@PathParam("name") final String name){
        Quiz q = quizDao.findByName(name);
        if (q == null) {
            return Response.status(Status.NOT_FOUND).build();
        }
        return Response.ok(getQuizDtofromQuiz(q)).build();
    }
	

	@GET
	public List<QuizDto> listAll(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		final List<Quiz> quizes = quizDao.findAll();
		List<QuizDto> quizDtoes = new LinkedList<QuizDto>();
		for (Quiz quiz : quizes) {
			quizDtoes.add(getQuizDtofromQuiz(quiz));
		}
		return quizDtoes;
	}


	@PUT
	@Path("/{id:[0-9][0-9]*}")
	public Response update(@PathParam("id") Long id, final QuizDto quizdto) {
		Quiz q = quizDao.findById(id.intValue());
		return Response.noContent().build();
	}

	@DELETE
	@Path("/{id:[0-9][0-9]*}")
	public Response deleteById(@PathParam("id") final Long id) {
		quizDao.delete(id.intValue());
		return Response.noContent().build();
	}
	
	public QuizDto getQuizDtofromQuiz(Quiz q)
	{
		QuizDto quizdto = new QuizDto();
		quizdto.setId(q.getId());
		
		quizdto.setAge(q.getAge());
		quizdto.setCreationDate(q.getCreationDate());
		quizdto.setDescription(q.getDescription());
		quizdto.setMultiplay(q.getMultiplay());
		quizdto.setName(q.getName());
		quizdto.setPicture(q.getPicture());
		
		CategoryDto category = new CategoryEndpoint().getCategoryDtofromCategory(q.getCategory());
		quizdto.setCategory(category);
		
		QuiztypeDto quiztype = new QuizTypeEndpoint().getQuizTypeDtofromQuiztype(q.getQuiztype());
		quizdto.setQuiztype(quiztype);
		
		UserDto user = new UserEndpoint().getUserDtofromUser(q.getUser());
		quizdto.setUser(user);

		
		return quizdto;
	}


	public Quiz getQuizfromQuizDto(QuizDto q) {
		Quiz quiz = new Quiz();
		quiz.setId(q.getId());
		
		quiz.setAge(q.getAge());
		quiz.setCreationDate(q.getCreationDate());
		quiz.setDescription(q.getDescription());
		quiz.setMultiplay(q.getMultiplay());
		quiz.setName(q.getName());
		quiz.setPicture(q.getPicture());
		
		int id = q.getCategory().getId();
		System.out.println("<--------------------------"+id+"------------------------------>");
		at.ac.htlleonding.jast.model.Category cat = catDao.findById(q.getCategory().getId());
		quiz.setCategory(cat);
		
		Quiztype quiztype =typeDao.findById(q.getQuiztype().getId());
		quiz.setQuiztype(quiztype);
		
		User user = userDao.findById(q.getUser().getId());
		quiz.setUser(user);

		return quiz;
	}




}
