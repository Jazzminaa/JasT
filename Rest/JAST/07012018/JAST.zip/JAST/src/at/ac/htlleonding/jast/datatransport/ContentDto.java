package at.ac.htlleonding.jast.datatransport;



public class ContentDto  {

	private int id;

	private String input1;

	private String input2;

	private String picture1;

	private String picture2;
	private QuizDto quiz;

	public ContentDto() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInput1() {
		return input1;
	}

	public void setInput1(String input1) {
		this.input1 = input1;
	}

	public String getInput2() {
		return input2;
	}

	public void setInput2(String input2) {
		this.input2 = input2;
	}

	public String getPicture1() {
		return picture1;
	}

	public void setPicture1(String picture1) {
		this.picture1 = picture1;
	}

	public String getPicture2() {
		return picture2;
	}

	public void setPicture2(String picture2) {
		this.picture2 = picture2;
	}

	public QuizDto getQuiz() {
		return quiz;
	}

	public void setQuiz(QuizDto quiz) {
		this.quiz = quiz;
	}

	
	

}