package at.ac.htlleonding.jast.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the multiplay database table.
 * 
 */
@Entity
@NamedQuery(name="Multiplay.findAll", query="SELECT m FROM Multiplay m")
public class Multiplay implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private int counter;

	private String timestamp;

	//bi-directional many-to-one association to Quiz
	@ManyToOne
	private Quiz quiz;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="owner")
	private User user;

	/*//bi-directional many-to-one association to Rightanswer
	@OneToMany(mappedBy="multiplay")
	private List<Rightanswer> rightanswers;

	//bi-directional many-to-one association to User
	@OneToMany(mappedBy="multiplay")
	private List<User> users;*/

	public Multiplay() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCounter() {
		return this.counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public String getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public Quiz getQuiz() {
		return this.quiz;
	}

	public void setQuiz(Quiz quiz) {
		this.quiz = quiz;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/*public List<Rightanswer> getRightanswers() {
		return this.rightanswers;
	}

	public void setRightanswers(List<Rightanswer> rightanswers) {
		this.rightanswers = rightanswers;
	}

	public Rightanswer addRightanswer(Rightanswer rightanswer) {
		getRightanswers().add(rightanswer);
		rightanswer.setMultiplay(this);

		return rightanswer;
	}

	public Rightanswer removeRightanswer(Rightanswer rightanswer) {
		getRightanswers().remove(rightanswer);
		rightanswer.setMultiplay(null);

		return rightanswer;
	}

	public List<User> getUsers() {
		return this.users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public User addUser(User user) {
		getUsers().add(user);
		user.setMultiplay(this);

		return user;
	}

	public User removeUser(User user) {
		getUsers().remove(user);
		user.setMultiplay(null);

		return user;
	}*/

}