package at.ac.htlleonding.jast.endpoint;


import java.util.LinkedList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.Status;

import at.ac.htlleonding.jast.dataaccess.*;
import at.ac.htlleonding.jast.datatransport.*;
import at.ac.htlleonding.jast.model.*;

@RequestScoped
@Path("/scores")
@Produces("application/json")
@Consumes("application/json")
public class ScoreEndpoint {
	
	@Inject
	ScoreDao scoreDao;
	
	@Inject
	CategoryDao categoryDao;
	
	@Inject
	QuizTypeDao quizTypeDao;
	
	@Inject
	UserDao userDao;

	@POST
	public Response create(final ScoreDto scoreDto) {
		Score score = new Score();
		scoreDao.add(getScorefromScoreDto(scoreDto));	
		return Response.created(UriBuilder.fromResource(ScoreEndpoint.class).path(String.valueOf(score.getId())).build()).build();
	}


	@GET
	@Path("/{id:[0-9][0-9]*}")
	public Response findById(@PathParam("id") final Long id) {
		Score q = scoreDao.findById(id.intValue());
		if (q == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(q).build();
	}
	
	

	@GET
	public List<ScoreDto> listAll(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		final List<Score> score = scoreDao.findAll();
		List<ScoreDto> scordtoes = new LinkedList<ScoreDto>();
		
		for(Score s : score) {
			scordtoes.add(getScoreDtofromScore(s));
		}
		return scordtoes;
	}

	@PUT
	@Path("/{id:[0-9][0-9]*}")
	public Response update(@PathParam("id") Long id, final Quiz userdto) {
		Score u = scoreDao.findById(id.intValue());
		//userDao.edit(getUserFromDto(userdto, u, false, userDao, householdDao, householduserDao, countryDao, userroleDao, pocketmoneycalculatorDao));
		return Response.noContent().build();
	}

	@DELETE
	@Path("/{id:[0-9][0-9]*}")
	public Response deleteById(@PathParam("id") final Long id) {
		scoreDao.delete(id.intValue());
		return Response.noContent().build();
	}
	
	public Score getScorefromScoreDto(ScoreDto s) {
		Score score = new Score();
		score.setId(s.getId());
		score.setPoints(s.getPoints());
		
		Category category = new CategoryEndpoint().getCategoryfromCategoryDto(s.getCategory(),categoryDao);
		score.setCategory(category);
		
		Quiztype quiztype = new QuizTypeEndpoint().getQuizTypefromQuiztypeDto(s.getQuiztype(),quizTypeDao);
		score.setQuiztype(quiztype);
		
		User user = new UserEndpoint().getUserfromUserDto(s.getUser(),userDao);
		score.setUser(user);

		return score;
	}
	public ScoreDto getScoreDtofromScore(Score s)
	{
		ScoreDto scoredto = new ScoreDto();
		scoredto.setId(s.getId());
		scoredto.setPoints(s.getPoints());
		
		CategoryDto category = new CategoryEndpoint().getCategoryDtofromCategory(s.getCategory());
		scoredto.setCategory(category);
		
		QuiztypeDto quiztype = new QuizTypeEndpoint().getQuizTypeDtofromQuiztype(s.getQuiztype());
		scoredto.setQuiztype(quiztype);
		
		UserDto user = new UserEndpoint().getUserDtofromUser(s.getUser());
		scoredto.setUser(user);
		return scoredto;
	}


}
