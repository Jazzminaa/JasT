package at.ac.htlleonding.jast.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the quiz database table.
 * 
 */
@Entity
@NamedQuery(name="Quiz.findAll", query="SELECT q FROM Quiz q")
public class Quiz implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private int age;

	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	private String description;

	private Integer multiplay;

	private String name;

	@Lob
	private String picture;

	private Timestamp timestamp;

	/*//bi-directional many-to-one association to Content
	@OneToMany(mappedBy="quiz")
	private List<Content> contents;

	//bi-directional many-to-one association to Multiplay
	@OneToMany(mappedBy="quiz")
	private List<Multiplay> multiplays;*/

	//bi-directional many-to-one association to Category
	@ManyToOne
	private Category category;

	//bi-directional many-to-one association to Quiztype
	@ManyToOne
	private Quiztype quiztype;

	//bi-directional many-to-one association to User
	@ManyToOne
	private User user;

	public Quiz() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Date getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getMultiplay() {
		return this.multiplay;
	}

	public void setMultiplay(int multiplay) {
		this.multiplay = multiplay;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPicture() {
		return this.picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public Timestamp getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	/*public List<Content> getContents() {
		return this.contents;
	}

	public void setContents(List<Content> contents) {
		this.contents = contents;
	}

	public Content addContent(Content content) {
		getContents().add(content);
		content.setQuiz(this);

		return content;
	}

	public Content removeContent(Content content) {
		getContents().remove(content);
		content.setQuiz(null);

		return content;
	}

	public List<Multiplay> getMultiplays() {
		return this.multiplays;
	}

	public void setMultiplays(List<Multiplay> multiplays) {
		this.multiplays = multiplays;
	}

	public Multiplay addMultiplay(Multiplay multiplay) {
		getMultiplays().add(multiplay);
		multiplay.setQuiz(this);

		return multiplay;
	}

	public Multiplay removeMultiplay(Multiplay multiplay) {
		getMultiplays().remove(multiplay);
		multiplay.setQuiz(null);

		return multiplay;
	}*/

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Quiztype getQuiztype() {
		return this.quiztype;
	}

	public void setQuiztype(Quiztype quiztype) {
		this.quiztype = quiztype;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}