package at.ac.htlleonding.jast.endpoint;


import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.Status;

import at.ac.htlleonding.jast.dataaccess.*;
import at.ac.htlleonding.jast.datatransport.*;
import at.ac.htlleonding.jast.model.*;

@RequestScoped
@Path("/content")
@Produces("application/json")
@Consumes("application/json")
public class ContentEndpoint {
	
	@Inject
	ContentDao contentDao;
	
	@Inject
	QuizDao quizDao;
	
	@Inject
	CategoryDao catDao;
	
	@Inject
	QuizTypeDao typeDao;
	
	@Inject
	UserDao userDao;
	

	@POST
	public Response create(final ContentDto contentdto) {
		Content con = new Content();
		contentDao.add(getContentFromContentDto(contentdto, con, contentDao));	
		return Response.created(UriBuilder.fromResource(ContentEndpoint.class).path(String.valueOf(con.getId())).build()).build();
	}



	@GET
	@Path("/{id:[0-9][0-9]*}")
	public Response findById(@PathParam("id") final Long id) {
		Content con = contentDao.findById(id.intValue());
		if (con == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(getContentDtoFromContnet(con)).build();
	}
	
	@GET
	public List<Content> listAll(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		final List<Content> users = contentDao.findAll();
		List<Content> userdtoes = new LinkedList<Content>();
		
		for(Content u : users) {
			userdtoes.add(u);
		}
		return userdtoes;
	}

	@PUT
	@Path("/{id:[0-9][0-9]*}")
	public Response update(@PathParam("id") Long id, final Quiz userdto) {
		Content u = contentDao.findById(id.intValue());
		//userDao.edit(getUserFromDto(userdto, u, false, userDao, householdDao, householduserDao, countryDao, userroleDao, pocketmoneycalculatorDao));
		return Response.noContent().build();
	}

	@DELETE
	@Path("/{id:[0-9][0-9]*}")
	public Response deleteById(@PathParam("id") final Long id) {
		contentDao.delete(id.intValue());
		return Response.noContent().build();
	}
	
	private ContentDto getContentDtoFromContnet(Content con) {
		ContentDto contentDto = new ContentDto();
		contentDto.setId(con.getId());
		contentDto.setInput1(con.getInput1());
		contentDto.setInput2(con.getInput2());
		contentDto.setPicture1(con.getPicture1());
		contentDto.setPicture2(con.getPicture2());
		
		QuizDto quiz = new QuizEndpoint().getQuizDtofromQuiz(con.getQuiz());
		contentDto.setQuiz(quiz);

		return contentDto;
	}
	private Content getContentFromContentDto(ContentDto contentDto, Content content , ContentDao contentDao2) {
		content.setId(contentDto.getId());
		content.setInput1(contentDto.getInput1());
		content.setInput2(contentDto.getInput2());
		content.setPicture1(contentDto.getPicture1());
		content.setPicture2(contentDto.getPicture2());
		
		Quiz quiz = quizDao.findById(contentDto.getQuiz().getId());
		content.setQuiz(quiz);

		return content;
	}


}
