package at.ac.htlleonding.jast.endpoint;

import java.io.IOException;
import java.sql.Date;
import java.util.LinkedList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import at.ac.htlleonding.jast.dataaccess.*;
import at.ac.htlleonding.jast.datatransport.*;
import at.ac.htlleonding.jast.model.*;

@RequestScoped
@Path("/quiztypes")
@Produces("application/json")
@Consumes("application/json")
public class QuizTypeEndpoint {
	
	
	@Inject
	QuizTypeDao quizTypeDao;

	@GET
	@Path("/{id:[0-9][0-9]*}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response findById(@PathParam("id") final Long id) throws IOException {
		Quiztype q = quizTypeDao.findById(id.intValue());
		if (q == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(getQuizTypeDtofromQuiztypew(q)).build();
	}
	
	@GET
    @Path("/{name}")
    public Response findByName(@PathParam("name") final String name){
		Quiztype q = quizTypeDao.findByName(name);
        if (q == null) {
            return Response.status(Status.NOT_FOUND).build();
        }
        return Response.ok(getQuizTypeDtofromQuiztypew(q)).build();
    }
	
	@GET
	public List<Quiztype> listAll(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		final List<Quiztype> types = quizTypeDao.findAll();
		List<Quiztype> typelist = new LinkedList<Quiztype>();
		
		for(Quiztype t : types) {
			typelist.add(t);
		}
		return typelist;
	}

	public QuiztypeDto getQuizTypeDtofromQuiztypew(Quiztype qt) {
		QuiztypeDto quiztypeDto = new QuiztypeDto();
		quiztypeDto.setId(qt.getId());
		quiztypeDto.setName(qt.getName());
		return quiztypeDto;
		
	}

	public Quiztype getQuizTypefromQuiztypeDto(QuiztypeDto qt) {
		Quiztype quiztype;
		
		quiztype = quizTypeDao.findById(qt.getId());
		if(quiztype == null) {
			quiztype = new Quiztype();
		}
		quiztype.setId(qt.getId());
		quiztype.setName(qt.getName());
		return quiztype;
	}

	


}
