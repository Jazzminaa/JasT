package at.ac.htlleonding.jast.datatransport;



public class RightanswerDto{

	private int id;

	private ContentDto Content;

	private MultiplayDto multiplay;

	private UserDto user;

	public RightanswerDto() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ContentDto getContent() {
		return Content;
	}

	public void setContent(ContentDto content) {
		Content = content;
	}

	public MultiplayDto getMultiplay() {
		return multiplay;
	}

	public void setMultiplay(MultiplayDto multiplay) {
		this.multiplay = multiplay;
	}

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}



}