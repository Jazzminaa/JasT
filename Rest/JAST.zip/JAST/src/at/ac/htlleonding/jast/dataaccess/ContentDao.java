package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import at.ac.htlleonding.jast.model.*;

@Named
@Dependent
public class ContentDao implements DataAccessObject<Content> {
	
	@PersistenceContext
	EntityManager em;

	public Content findById(int id) {
		return em.find(Content.class, id);
	}

	public List<Content> findAll() {
		return em.createNamedQuery("Content.findAll", Content.class).getResultList();
	}

	@Transactional
	public void add(Content t) {
		em.persist(t);
	}


	@Transactional
	public void delete(int id) {
		Content c = em.find(Content.class, id);
		em.remove(c);
	}

	@Transactional
	public void edit(Content t) {
		Content c = em.find(Content.class, t.getId());
		em.merge(c);
	}
	

}
