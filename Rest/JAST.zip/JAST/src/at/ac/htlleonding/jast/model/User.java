package at.ac.htlleonding.jast.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dateOfBirth;

	private String email;

	private String firstname;

	private String gender;

	private String lastname;

	private String password;

	@Lob
	private String picture;

	private Timestamp timestamp;

	private String username;

	/*//bi-directional many-to-one association to Multiplay
	@OneToMany(mappedBy="user")
	private List<Multiplay> multiplays;

	//bi-directional many-to-one association to Quiz
	@OneToMany(mappedBy="user")
	private List<Quiz> quizs;

	//bi-directional many-to-one association to Rightanswer
	@OneToMany(mappedBy="user")
	private List<Rightanswer> rightanswers;

	//bi-directional many-to-one association to Score
	@OneToMany(mappedBy="user")
	private List<Score> scores;*/

	//bi-directional many-to-one association to Multiplay
	@ManyToOne
	@JoinColumn(name="Multiplayer_id")
	private Multiplay multiplay;

	public User() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPicture() {
		return this.picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public Timestamp getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	/*public List<Multiplay> getMultiplays() {
		return this.multiplays;
	}

	public void setMultiplays(List<Multiplay> multiplays) {
		this.multiplays = multiplays;
	}

	public Multiplay addMultiplay(Multiplay multiplay) {
		getMultiplays().add(multiplay);
		multiplay.setUser(this);

		return multiplay;
	}

	public Multiplay removeMultiplay(Multiplay multiplay) {
		getMultiplays().remove(multiplay);
		multiplay.setUser(null);

		return multiplay;
	}

	public List<Quiz> getQuizs() {
		return this.quizs;
	}

	public void setQuizs(List<Quiz> quizs) {
		this.quizs = quizs;
	}

	public Quiz addQuiz(Quiz quiz) {
		getQuizs().add(quiz);
		quiz.setUser(this);

		return quiz;
	}

	public Quiz removeQuiz(Quiz quiz) {
		getQuizs().remove(quiz);
		quiz.setUser(null);

		return quiz;
	}

	public List<Rightanswer> getRightanswers() {
		return this.rightanswers;
	}

	public void setRightanswers(List<Rightanswer> rightanswers) {
		this.rightanswers = rightanswers;
	}

	public Rightanswer addRightanswer(Rightanswer rightanswer) {
		getRightanswers().add(rightanswer);
		rightanswer.setUser(this);

		return rightanswer;
	}

	public Rightanswer removeRightanswer(Rightanswer rightanswer) {
		getRightanswers().remove(rightanswer);
		rightanswer.setUser(null);

		return rightanswer;
	}

	public List<Score> getScores() {
		return this.scores;
	}

	public void setScores(List<Score> scores) {
		this.scores = scores;
	}

	public Score addScore(Score score) {
		getScores().add(score);
		score.setUser(this);

		return score;
	}

	public Score removeScore(Score score) {
		getScores().remove(score);
		score.setUser(null);

		return score;
	}*/

	public Multiplay getMultiplay() {
		return this.multiplay;
	}

	public void setMultiplay(Multiplay multiplay) {
		this.multiplay = multiplay;
	}

}