package at.ac.htlleonding.jast.datatransport;



public class MultiplayDto  {
	
	private int id;

	private int counter;

	private QuizDto quiz;

	private UserDto ownwer;
	
	public MultiplayDto() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public QuizDto getQuiz() {
		return quiz;
	}

	public void setQuiz(QuizDto quiz) {
		this.quiz = quiz;
	}

	public UserDto getOwnwer() {
		return ownwer;
	}

	public void setOwnwer(UserDto ownwer) {
		this.ownwer = ownwer;
	}

	

}