package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import at.ac.htlleonding.jast.model.*;

@Named
@Dependent
public class QuizDao implements DataAccessObject<Quiz> {
	
	@PersistenceContext
	EntityManager em;

	public Quiz findById(int id) {
		return em.find(Quiz.class, id);
	}

	public List<Quiz> findAll() {
		List<Quiz> q = em.createNamedQuery("Quiz.findAll", Quiz.class).getResultList(); //Ein Error
		return q;
	}

	@Transactional
	public void add(Quiz t) {
		em.persist(t);
	}


	@Transactional
	public void delete(int id) {
		Quiz q = em.find(Quiz.class, id);
		em.remove(q);
	}

	@Transactional
	public void edit(Quiz t) {
		Quiz q = em.find(Quiz.class, t.getId());
		q.setName(t.getName());
		q.setCreationDate(t.getCreationDate());
		//q.setPicture(t.getPicture());
		q.setDescription(t.getDescription());
		q.setQuiztype(t.getQuiztype());
		q.setUser(t.getUser());
		em.merge(q);
	}
	


	public Quiz findByName(String name) {
		return (Quiz) em.createQuery("select q from Quiz q where q.name = :name").setParameter("name", name).getSingleResult();
	}

}
