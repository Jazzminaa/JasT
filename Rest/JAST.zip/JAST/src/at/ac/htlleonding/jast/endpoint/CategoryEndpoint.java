package at.ac.htlleonding.jast.endpoint;


import java.util.LinkedList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import at.ac.htlleonding.jast.dataaccess.*;
import at.ac.htlleonding.jast.datatransport.*;
import at.ac.htlleonding.jast.model.*;

@RequestScoped
@Path("/categories")
@Produces("application/json")
@Consumes("application/json")
public class CategoryEndpoint {
	
	@Inject
	CategoryDao categoryDao;
	

	@GET
	@Path("/{id:[0-9][0-9]*}")
	public Response findById(@PathParam("id") final Long id) {
		Category q = categoryDao.findById(id.intValue());
		if (q == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(getCategoryDtofromCategory(q)).build();
	}
	
	
	
	@GET
    @Path("/{name}")
    public Response findByName(@PathParam("name") final String name){
		Category q = categoryDao.findByName(name);
        if (q == null) {
            return Response.status(Status.NOT_FOUND).build();
        }
        return Response.ok(getCategoryDtofromCategory(q)).build();
    }
	
	

	@GET
	public List<Category> listAll(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		final List<Category> users = categoryDao.findAll();
		List<Category> userdtoes = new LinkedList<Category>();
		
		for(Category u : users) {
			userdtoes.add(u);
		}
		return userdtoes;
	}



	public CategoryDto getCategoryDtofromCategory(Category c) {
		CategoryDto catDto = new CategoryDto();
		catDto.setId(c.getId());
		catDto.setName(c.getName());
		return catDto;
	}



	public Category getCategoryfromCategoryDto(CategoryDto categorydto) {
		Category cat;
		
		cat = categoryDao.findById(categorydto.getId());
		if(cat == null) {
			cat = new Category();
		}
		cat.setId(categorydto.getId());
		cat.setName(categorydto.getName());
		return cat;
	}




}
