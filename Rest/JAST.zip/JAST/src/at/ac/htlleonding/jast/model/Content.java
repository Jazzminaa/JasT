package at.ac.htlleonding.jast.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the content database table.
 * 
 */
@Entity
@NamedQuery(name="Content.findAll", query="SELECT c FROM Content c")
public class Content implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String input1;

	private String input2;

	@Lob
	private String picture1;

	@Lob
	private String picture2;

	private Timestamp timestamp;

	//bi-directional many-to-one association to Quiz
	@ManyToOne
	private Quiz quiz;

	/*//bi-directional many-to-one association to Rightanswer
	@OneToMany(mappedBy="content")
	private List<Rightanswer> rightanswers;*/

	public Content() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInput1() {
		return this.input1;
	}

	public void setInput1(String input1) {
		this.input1 = input1;
	}

	public String getInput2() {
		return this.input2;
	}

	public void setInput2(String input2) {
		this.input2 = input2;
	}

	public String getPicture1() {
		return this.picture1;
	}

	public void setPicture1(String picture1) {
		this.picture1 = picture1;
	}

	public String getPicture2() {
		return this.picture2;
	}

	public void setPicture2(String picture2) {
		this.picture2 = picture2;
	}

	public Timestamp getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public Quiz getQuiz() {
		return this.quiz;
	}

	public void setQuiz(Quiz quiz) {
		this.quiz = quiz;
	}

	/*public List<Rightanswer> getRightanswers() {
		return this.rightanswers;
	}

	public void setRightanswers(List<Rightanswer> rightanswers) {
		this.rightanswers = rightanswers;
	}

	public Rightanswer addRightanswer(Rightanswer rightanswer) {
		getRightanswers().add(rightanswer);
		rightanswer.setContent(this);

		return rightanswer;
	}

	public Rightanswer removeRightanswer(Rightanswer rightanswer) {
		getRightanswers().remove(rightanswer);
		rightanswer.setContent(null);

		return rightanswer;
	}*/

}