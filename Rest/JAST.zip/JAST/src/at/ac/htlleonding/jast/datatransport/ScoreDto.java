package at.ac.htlleonding.jast.datatransport;



public class ScoreDto {

	private int id;

	private String points;
	

	private CategoryDto category;

	private QuiztypeDto quiztype;

	private UserDto user;

	public ScoreDto() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPoints() {
		return points;
	}

	public void setPoints(String points) {
		this.points = points;
	}

	public CategoryDto getCategory() {
		return category;
	}

	public void setCategory(CategoryDto category) {
		this.category = category;
	}

	public QuiztypeDto getQuiztype() {
		return quiztype;
	}

	public void setQuiztype(QuiztypeDto quiztype) {
		this.quiztype = quiztype;
	}

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}

}