package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import at.ac.htlleonding.jast.model.*;

@Named
@Dependent
public class RightanswerDao implements DataAccessObject<Rightanswer> {
	
	@PersistenceContext
	EntityManager em;

	public Rightanswer findById(int id) {
		return em.find(Rightanswer.class, id);
	}

	public List<Rightanswer> findAll() {
		return em.createNamedQuery("Rightanswer.findAll", Rightanswer.class).getResultList();
	}

	@Transactional
	public void add(Rightanswer t) {
		em.persist(t);
	}


	@Transactional
	public void delete(int id) {
		Rightanswer c = em.find(Rightanswer.class, id);
		em.remove(c);
	}

	@Transactional
	public void edit(Rightanswer t) {
		Rightanswer c = em.find(Rightanswer.class, t.getId());
		em.merge(c);
	}

}
