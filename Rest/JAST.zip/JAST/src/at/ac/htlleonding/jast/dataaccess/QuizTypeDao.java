package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import at.ac.htlleonding.jast.model.*;

@Named
@Dependent
public class QuizTypeDao implements DataAccessObject<Quiztype> {
	
	@PersistenceContext
	EntityManager em;

	public Quiztype findById(int id) {
		return em.find(Quiztype.class, id);
	}

	public List<Quiztype> findAll() {
		return em.createNamedQuery("Quiztype.findAll", Quiztype.class).getResultList();
	}

	@Transactional
	public void add(Quiztype t) {
		em.persist(t);
	}


	@Transactional
	public void delete(int id) {
		Quiztype c = em.find(Quiztype.class, id);
		em.remove(c);
	}

	@Transactional
	public void edit(Quiztype t) {
		Quiztype c = em.find(Quiztype.class, t.getId());
		c.setName(t.getName());
		em.merge(c);
	}
	


	public Quiztype findByName(String name) {
		return (Quiztype) em.createQuery("select q from Quiztype q where q.name = :name").setParameter("name", name).getSingleResult();
	}

}
