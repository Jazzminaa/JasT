package at.ac.htlleonding.jast.dataaccess;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import at.ac.htlleonding.jast.model.*;

@Named
@Dependent
public class CategoryDao implements DataAccessObject<Category> {
	
	@PersistenceContext
	EntityManager em;

	public Category findById(int id) {
		return em.find(Category.class, id);
	}

	public List<Category> findAll() {
		return em.createNamedQuery("Category.findAll", Category.class).getResultList();
	}

	@Transactional
	public void add(Category t) {
		em.persist(t);
	}


	@Transactional
	public void delete(int id) {
		Category c = em.find(Category.class, id);
		em.remove(c);
	}

	@Transactional
	public void edit(Category t) {
		Category c = em.find(Category.class, t.getId());
		c.setName(t.getName());
		em.merge(c);
	}
	


	public Category findByName(String name) {
		return (Category) em.createQuery("select c from Category c where c.name = :name").setParameter("name", name).getSingleResult();
	}

}
